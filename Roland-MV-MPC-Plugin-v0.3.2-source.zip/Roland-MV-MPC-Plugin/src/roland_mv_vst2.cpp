// Roland MV Library instrument prototype for legacy VST2 hosts.
// Implements 16-pad MIDI triggering and PCM WAV playback; proprietary Roland
// project/patch decoding and native MPC GUI integration are not implemented here.
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include <dirent.h>
#include <cctype>
#include <sys/stat.h>

#if defined(_WIN32)
#define EXPORT extern "C" __declspec(dllexport)
#else
#define EXPORT extern "C" __attribute__((visibility("default")))
#endif
using VstInt32=int32_t; using VstIntPtr=intptr_t;
struct AEffect;
using AudioMasterCallback=VstIntPtr(*)(AEffect*,VstInt32,VstInt32,VstIntPtr,void*,float);
using DispatcherProc=VstIntPtr(*)(AEffect*,VstInt32,VstInt32,VstIntPtr,void*,float);
using ProcessProc=void(*)(AEffect*,float**,float**,VstInt32);
using SetParameterProc=void(*)(AEffect*,VstInt32,float);
using GetParameterProc=float(*)(AEffect*,VstInt32);
struct AEffect { VstInt32 magic; DispatcherProc dispatcher; ProcessProc process; SetParameterProc setParameter; GetParameterProc getParameter; VstInt32 numPrograms,numParams,numInputs,numOutputs,flags; VstIntPtr resvd1,resvd2; VstInt32 initialDelay,realQualities,offQualities; float ioRatio; void*object; void*user; VstInt32 uniqueID,version; ProcessProc processReplacing,processDoubleReplacing; char future[56]; };
struct MidiEvent { VstInt32 type,byteSize,deltaFrames,flags; char data[16]; };
struct Events { VstInt32 numEvents; VstIntPtr reserved; MidiEvent* events[1]; };
struct Sample { std::vector<int16_t> l,r; double rate=44100.0; int rootKey=60; uint32_t slot=0; std::string name; bool stereo=false; bool loaded=false; };
struct Voice { int pad=-1, note=60; double pos=0.0; float velocity=1.f; bool active=false; int stage=0; float env=0.f, relStep=0.f, ic1[2]={0,0}, ic2[2]={0,0}; };
struct QueuedMidi { int frame=0; int note=0; int velocity=0; bool on=false; };
static QueuedMidi midiQueue[512]; static int midiQueueCount=0;
static AEffect fx{}; static double sr=44100.0; static float master=0.8f; static std::vector<Sample> samples; static Voice voices[64]; static std::vector<std::string> patchPaths; static int currentProgram=0; static int synthMode=0;
#ifndef ROLAND_MV_SAMPLE_DIR
#define ROLAND_MV_SAMPLE_DIR "/sdcard/Synths/mvlib - VST - MV-8000/Samples"
#endif
static const char* SAMPLE_DIR=ROLAND_MV_SAMPLE_DIR;
static std::string patchRoot(){ return std::string(SAMPLE_DIR)+"/Patches"; }
enum { effOpen=0,effClose=1,effSetProgram=2,effGetProgram=3,effSetProgramName=4,effGetProgramName=5,effSetSampleRate=10,effSetBlockSize=11,effMainsChanged=12,effGetChunk=23,effSetChunk=24,effProcessEvents=25,effGetEffectName=45,effGetVendorString=47,effGetProductString=48,effGetVendorVersion=49,effCanDo=51,effGetVstVersion=58 };
static uint16_t u16(const unsigned char*p){return (uint16_t)(p[0]|(p[1]<<8));}
static uint32_t u32(const unsigned char*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static bool loadWav(const std::string& path, Sample& out) {
  std::ifstream f(path.c_str(),std::ios::binary); if(!f) return false;
  std::vector<unsigned char>b((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>());
  if(b.size()<44 || std::memcmp(&b[0],"RIFF",4)||std::memcmp(&b[8],"WAVE",4)) return false;
  uint16_t fmt=0,ch=0,bits=0; uint32_t rate=0; size_t dataOff=0,dataLen=0;
  for(size_t p=12;p+8<=b.size();) { uint32_t n=u32(&b[p+4]); size_t start=p+8; if(n>b.size()-start) break;
    if(!std::memcmp(&b[p],"fmt ",4)&&n>=16){fmt=u16(&b[start]);ch=u16(&b[start+2]);rate=u32(&b[start+4]);bits=u16(&b[start+14]);}
    if(!std::memcmp(&b[p],"data",4)){dataOff=start;dataLen=n;break;} p=start+n+(n&1);
  }
  if(fmt!=1 || (ch!=1&&ch!=2) || bits!=16 || !rate || !dataLen || dataOff+dataLen>b.size()) return false;
  size_t frames=dataLen/(2*ch); if(!frames || frames>rate*120u) return false;
  out.l.resize(frames); if(ch==2)out.r.resize(frames); else out.r.clear(); out.rate=rate;
  for(size_t i=0;i<frames;i++){ const unsigned char*p=&b[dataOff+i*2*ch]; int16_t a=(int16_t)u16(p); int16_t c=ch==2?(int16_t)u16(p+2):a; out.l[i]=a; if(ch==2)out.r[i]=c; }
  out.loaded=true; return true;
}
// MVFF (.MV0) loader. Layout observed in a real MV drum kit: MVFF hdr, FMT, PRM(kit), SMPL{ u32 0, then
// repeated PRM(0x26)+WAVE(u32be bytes, signed 16-bit BE PCM) }. PRM flag @body+34 == 0x0100 -> interleaved stereo, else mono.
// Sample rate is not decoded from the file; 44.1 kHz is assumed.
static uint32_t be32(const unsigned char*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|(uint32_t)p[3];}
static uint16_t be16(const unsigned char*p){return (uint16_t)((p[0]<<8)|p[1]);}
static int loadMvff(const std::string& path, std::vector<Sample>& out){
  std::ifstream f(path.c_str(),std::ios::binary); if(!f) return 0;
  std::vector<unsigned char>b((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>());
  if(b.size()<32||std::memcmp(&b[0],"MVFF",4)) return 0;
  size_t pos=16, smpl=0, smplEnd=0;
  while(pos+8<=b.size()){ uint32_t n=be32(&b[pos+4]); if(n>b.size()-(pos+8)) break;
    if(!std::memcmp(&b[pos],"SMPL",4)){smpl=pos+8;smplEnd=pos+8+n;break;} pos+=8+n; }
  if(!smpl||smpl+4>smplEnd) return 0;
  out.clear(); int n=0; pos=smpl+4;
  while(pos+8<=smplEnd && !std::memcmp(&b[pos],"PRM ",4)){
    uint32_t pl=be32(&b[pos+4]); size_t w=pos+8+pl; if(pl<0x26||w+8>smplEnd||std::memcmp(&b[w],"WAVE",4)) break;
    bool stereo=be16(&b[pos+8+34])==0x0100;
    uint32_t len=be32(&b[w+4]); size_t st=w+8; if(len>smplEnd-st) break;
    size_t step=stereo?4:2, frames=len/step;
    // The per-sample PRM stores an end-frame index at body offset 28. Respect
    // it when it is a valid in-range endpoint; otherwise retain the full WAVE.
    // This avoids playing unused trailing data present in some factory records.
    uint32_t endIndex=be32(&b[pos+8+28]);
    if(endIndex>0 && endIndex<frames) frames=(size_t)endIndex+1;
    if(frames && frames<=44100u*120u){
      out.emplace_back(); Sample&sm=out.back(); sm.l.assign(frames,0); if(stereo)sm.r.assign(frames,0); else sm.r.clear(); sm.rate=44100.0;
      sm.rootKey=(int)b[pos+8+33]; if(sm.rootKey>127)sm.rootKey=60;
      sm.slot=be32(&b[pos+8+4]); sm.stereo=stereo; sm.name.assign((const char*)&b[pos+8+8],12);
      size_t nul=sm.name.find('\0'); if(nul!=std::string::npos)sm.name.resize(nul);
      while(!sm.name.empty() && sm.name.back()==' ') sm.name.pop_back();
      for(size_t i=0;i<frames;i++){ const unsigned char*q=&b[st+i*step]; int16_t a=(int16_t)be16(q); int16_t c=stereo?(int16_t)be16(q+2):a; sm.l[i]=a; if(stereo)sm.r[i]=c; }
      sm.loaded=true; n++;
    }
    pos=st+len;
  }
  return n;
}
static bool endsWithMv0(const char* n){ size_t z=std::strlen(n); return z>=4 && std::tolower((unsigned char)n[z-4])=='.' && std::tolower((unsigned char)n[z-3])=='m' && std::tolower((unsigned char)n[z-2])=='v' && std::tolower((unsigned char)n[z-1])=='0'; }
static void scanPatches(const std::string& dir){
  DIR*d=opendir(dir.c_str()); if(!d)return; struct dirent*e;
  while((e=readdir(d))){
    if(!std::strcmp(e->d_name,".")||!std::strcmp(e->d_name,".."))continue;
    std::string p=dir+"/"+e->d_name; struct stat st;
    if(stat(p.c_str(),&st)!=0)continue;
    if(S_ISDIR(st.st_mode))scanPatches(p);
    else if(S_ISREG(st.st_mode)&&endsWithMv0(e->d_name))patchPaths.push_back(p);
  }
  closedir(d);
}
static void loadPads(){
  patchPaths.clear(); scanPatches(patchRoot()); std::sort(patchPaths.begin(),patchPaths.end());
  if(!patchPaths.empty()){
    fx.numPrograms=(VstInt32)patchPaths.size();
    int start=std::max(0,std::min(currentProgram,(int)patchPaths.size()-1));
    // Do not leave the instrument silent if the first alphabetic patch is damaged.
    // Try each candidate once, starting at the previously selected program.
    for(int attempt=0;attempt<(int)patchPaths.size();++attempt){
      int candidateIndex=(start+attempt)%(int)patchPaths.size(); std::vector<Sample> candidate;
      if(loadMvff(patchPaths[candidateIndex],candidate)>0){ currentProgram=candidateIndex; samples.swap(candidate); return; }
    }
  }
  fx.numPrograms=1; currentProgram=0;
  samples.clear(); char p[512]; std::snprintf(p,sizeof(p),"%s/kit.MV0",SAMPLE_DIR);
  std::vector<Sample> kit; if(loadMvff(p,kit)>0)samples.swap(kit);
  if(samples.empty()){ samples.resize(16); for(int i=0;i<16;i++){ std::snprintf(p,sizeof(p),"%s/pad%02d.wav",SAMPLE_DIR,i+1); loadWav(p,samples[i]); samples[i].rootKey=36+i; } }
}
static void selectProgram(int index){
  if(patchPaths.empty()||index<0||index>=(int)patchPaths.size())return;
  if(index==currentProgram&&!samples.empty())return;
  std::vector<Sample> candidate;
  if(loadMvff(patchPaths[index],candidate)<=0)return; // Keep the last playable patch if a file is damaged.
  currentProgram=index; samples.swap(candidate); for(auto &v:voices)v.active=false;
}

// ---- Parameters -------------------------------------------------------------------------------
// MPC skins bind controls by VST2 parameter INDEX ("Data" -> "Parameter N" in TUI.json, Q-Link N -> index in Q-Links.json),
// and the skin's Name/Value labels show effGetParamName/effGetParamDisplay, so names are short and human-readable.
// Per-pad parameters (Level..Gate) edit the pad chosen by "Pad"; "Pad N" (13-28) edits pad N's level directly.
enum { P_MASTER=0,P_PADSEL,P_LEVEL,P_PAN,P_COARSE,P_FINE,P_ATTACK,P_DECAY,P_SUSTAIN,P_RELEASE,P_GATE,P_CUTOFF,P_RES,P_PADVOL0, P_MODE=P_PADVOL0+16, NPARAMS=P_MODE+1 };
struct PadP { float level=.8f,pan=.5f,coarse=.5f,fine=.5f,attack=0.f,decay=.5f,sustain=1.f,release=.5f,gate=0.f; };
static PadP pp[16]; static int selPad=0; static float cutoffN=1.f,resN=0.f;
// Stable, versioned VST2 chunk format so hosts can persist all per-pad settings.
// This stores plugin parameters only; it is not an MV-8000 song/project container.
struct StateChunk { char magic[8]; uint32_t version; uint32_t bytes; float master, cutoff, resonance; uint32_t selectedPad; uint32_t synthMode; PadP pads[16]; };
static StateChunk stateChunk{};
static float clamp01(float v);
static const char STATE_MAGIC[8]={'M','V','M','P','C','S','T','1'};
static void saveStateChunk(){ stateChunk=StateChunk{}; std::memcpy(stateChunk.magic,STATE_MAGIC,8); stateChunk.version=2; stateChunk.bytes=sizeof(StateChunk); stateChunk.master=master; stateChunk.cutoff=cutoffN; stateChunk.resonance=resN; stateChunk.selectedPad=(uint32_t)std::max(0,std::min(15,selPad)); stateChunk.synthMode=(uint32_t)synthMode; for(int i=0;i<16;i++)stateChunk.pads[i]=pp[i]; }
static bool restoreStateChunk(const void* data, VstIntPtr bytes){ if(!data||bytes!=(VstIntPtr)sizeof(StateChunk))return false; StateChunk in; std::memcpy(&in,data,sizeof(in)); if(std::memcmp(in.magic,STATE_MAGIC,8)||in.version!=2||in.bytes!=sizeof(StateChunk)||in.selectedPad>15||in.synthMode>1)return false;
  master=clamp01(in.master); cutoffN=clamp01(in.cutoff); resN=clamp01(in.resonance); selPad=(int)in.selectedPad; synthMode=(int)in.synthMode;
  for(int i=0;i<16;i++){ pp[i]=in.pads[i]; pp[i].level=clamp01(pp[i].level); pp[i].pan=clamp01(pp[i].pan); pp[i].coarse=clamp01(pp[i].coarse); pp[i].fine=clamp01(pp[i].fine); pp[i].attack=clamp01(pp[i].attack); pp[i].decay=clamp01(pp[i].decay); pp[i].sustain=clamp01(pp[i].sustain); pp[i].release=clamp01(pp[i].release); pp[i].gate=clamp01(pp[i].gate); } return true; }
static const char* PNAME[14]={"Master","Pad","Level","Pan","Coarse","Fine","Attack","Decay","Sustain","Release","Gate","Cutoff","Reson","Mode"};
static float clamp01(float v){return std::max(0.f,std::min(1.f,v));}
static float* slot(VstInt32 i){switch(i){case P_LEVEL:return &pp[selPad].level;case P_PAN:return &pp[selPad].pan;case P_COARSE:return &pp[selPad].coarse;case P_FINE:return &pp[selPad].fine;case P_ATTACK:return &pp[selPad].attack;case P_DECAY:return &pp[selPad].decay;case P_SUSTAIN:return &pp[selPad].sustain;case P_RELEASE:return &pp[selPad].release;case P_GATE:return &pp[selPad].gate;case P_CUTOFF:return &cutoffN;case P_RES:return &resN;case P_MASTER:return &master;default:break;} if(i>=P_PADVOL0&&i<P_MODE)return &pp[i-P_PADVOL0].level; return nullptr;}
static void setP(AEffect*,VstInt32 i,float v){ v=clamp01(v); if(i==P_PADSEL){selPad=(int)std::lround(v*15.f);return;} if(i==P_MODE){synthMode=v>=0.5f?1:0;return;} float*p=slot(i); if(p)*p=v; }
static float getP(AEffect*,VstInt32 i){ if(i==P_PADSEL)return selPad/15.f; if(i==P_MODE)return synthMode?1.f:0.f; float*p=slot(i); return p?*p:0.f; }
static float timeOf(float n){return n<=0.f?0.f:0.002f*std::pow(5000.f,n);}
static void paramName(VstInt32 i,char*o){ if(i==P_MODE){std::snprintf(o,24,"Mode");return;} if(i>=0&&i<P_PADVOL0)std::snprintf(o,24,"%s",PNAME[i]); else if(i>=P_PADVOL0&&i<P_MODE)std::snprintf(o,24,"Pad %d",i-P_PADVOL0+1); else std::snprintf(o,24,"Unknown"); }
static void paramDisplay(VstInt32 i,char*o){ float v=getP(nullptr,i); switch(i){
  case P_MASTER:case P_LEVEL: if(v<=0.f)std::snprintf(o,24,"-inf dB"); else std::snprintf(o,24,"%.1f dB",20.0*std::log10(v/0.8)); return;
  case P_PADSEL: std::snprintf(o,24,"%d",selPad+1); return;
  case P_PAN: {int c=(int)std::lround((v-.5f)*127.f); if(c==0)std::snprintf(o,24,"C"); else std::snprintf(o,24,c<0?"L%d":"R%d",std::abs(c)); return;}
  case P_COARSE: std::snprintf(o,24,"%+d st",(int)std::lround((v-.5f)*48.f)); return;
  case P_FINE: std::snprintf(o,24,"%+d ct",(int)std::lround((v-.5f)*100.f)); return;
  case P_ATTACK:case P_DECAY:case P_RELEASE: std::snprintf(o,24,"%.3f s",timeOf(v)); return;
  case P_SUSTAIN: std::snprintf(o,24,"%d",(int)std::lround(v*127.f)); return;
  case P_GATE: std::snprintf(o,24,v>=.5f?"Gate":"One-shot"); return;
  case P_CUTOFF: std::snprintf(o,24,"%.0f Hz",20.0*std::pow(1000.0,(double)v)); return;
  case P_RES: std::snprintf(o,24,"%d%%",(int)std::lround(v*100.f)); return;
  case P_MODE: std::snprintf(o,24,synthMode?"Synth":"Drums"); return; default: if(i>=P_PADVOL0&&i<P_MODE){ if(v<=0.f)std::snprintf(o,24,"-inf dB"); else std::snprintf(o,24,"%.1f dB",20.0*std::log10(v/0.8)); } } }
// ---- Voices -----------------------------------------------------------------------------------
static int velocityLayer(const Sample &s){
  // Some Roland factory sample names encode layer tags immediately before
  // the root-note digits (for example CmpJBsMP024l / CmpJBsFF024l).
  // Only accept a tag followed by digits to avoid matching incidental letters
  // in names such as "CmpJBass". This remains a fallback, not native zone data.
  std::string n=s.name; for(size_t i=0;i<n.size();++i)n[i]=(char)std::toupper((unsigned char)n[i]);
  for(size_t i=0;i+2<n.size();++i){
    if(!std::isdigit((unsigned char)n[i+2]))continue;
    if(n.compare(i,2,"PP")==0)return 24;
    if(n.compare(i,2,"MP")==0)return 56;
    if(n.compare(i,2,"MF")==0)return 82;
    if(n.compare(i,2,"FF")==0)return 112;
  }
  // Some MV factory multisamples use single-character P/F tags immediately
  // before the root-note digits (e.g. FMasterP024l / FMasterF024l).
  // These are hints only; exact velocity zones live in the undecoded patch PRM.
  for(size_t i=1;i+1<n.size();++i){
    if(!std::isdigit((unsigned char)n[i+1]))continue;
    if(n[i]=='P')return 48;
    if(n[i]=='F')return 104;
  }
  return 64;
}
static int chooseSynthSample(int note,int velocity){
  int nearest=9999; for(const Sample &s:samples)if(s.loaded)nearest=std::min(nearest,std::abs(s.rootKey-note));
  if(nearest==9999)return -1;
  int best=-1,score=999999;
  for(size_t i=0;i<samples.size();++i){ const Sample&s=samples[i]; if(!s.loaded||std::abs(s.rootKey-note)!=nearest)continue;
    int cost=std::abs(velocityLayer(s)-velocity)*4+(int)i;
    if(cost<score){score=cost;best=(int)i;}
  }
  return best;
}
static void noteOn(int n,int vel){ if(vel<=0||samples.empty())return; int pad=-1;
  if(!synthMode){ if(n<36||n>=52)return; pad=n-36; if(pad>=(int)samples.size()||!samples[pad].loaded)return; }
  else { pad=chooseSynthSample(n,vel); if(pad<0)return; }
  int slotI=-1; for(int i=0;i<64;i++)if(!voices[i].active){slotI=i;break;} if(slotI<0)slotI=0; Voice&q=voices[slotI]; q=Voice(); q.pad=pad;q.note=n;q.velocity=vel/127.f;q.active=true; }
static void noteOff(int n){ for(int i=0;i<64;i++){Voice&q=voices[i]; if(!q.active||q.note!=n||q.pad<0)continue; int p=std::min(q.pad,15); if(pp[p].gate<.5f)continue; float rel=std::max(timeOf(pp[p].release),0.002f); if(q.stage!=2){q.stage=2;q.relStep=q.env/(rel*(float)sr);}} }
static void process(AEffect*,float**,float**o,VstInt32 n){ if(!o||!o[0]||!o[1])return;
  int midiAt=0;
  float atkInc[16],decDec[16],gl[16],gr[16];
  for(int p=0;p<16;p++){ const PadP&P=pp[p]; float a=timeOf(P.attack),d=timeOf(P.decay);
    atkInc[p]=a>0.f?1.f/(a*(float)sr):1.f; decDec[p]=d>0.f?(1.f-P.sustain)/(d*(float)sr):1.f;
    float ang=P.pan*1.5707963f; float g=P.level/0.8f; gl[p]=g*std::cos(ang)*1.4142135f; gr[p]=g*std::sin(ang)*1.4142135f; }
  bool filt=cutoffN<0.999f; float fcv=std::min(20.f*std::pow(1000.f,cutoffN),0.45f*(float)sr), gF=std::tan(3.14159265f*fcv/(float)sr), kF=2.f-1.95f*resN, a1=1.f/(1.f+gF*(gF+kF)), a2=gF*a1, a3=gF*a2;
  for(int i=0;i<n;i++){
    while(midiAt<midiQueueCount && midiQueue[midiAt].frame<=i){
      const QueuedMidi &m=midiQueue[midiAt++]; if(m.on)noteOn(m.note,m.velocity); else noteOff(m.note);
    }
    float l=0,r=0;
    for(int v=0;v<64;v++){Voice &q=voices[v];if(!q.active||q.pad<0||q.pad>=(int)samples.size())continue;Sample&s=samples[q.pad];if(!s.loaded){q.active=false;continue;} if(q.pos>=double(s.l.size())){q.active=false;continue;}
      const int p=std::min(q.pad,15); const PadP&P=pp[p];
      if(q.stage==0){ q.env+=atkInc[p]; if(q.env>=1.f){q.env=1.f;q.stage=1;} }
      else if(q.stage==1){ if(q.env>P.sustain){q.env-=decDec[p]; if(q.env<P.sustain)q.env=P.sustain;} }
      else { q.env-=q.relStep; if(q.env<=0.f){q.active=false;continue;} }
      size_t idx=(size_t)q.pos; size_t next=std::min(idx+1,s.l.size()-1); float frac=(float)(q.pos-(double)idx);
      float sl=(s.l[idx]+(s.l[next]-s.l[idx])*frac)/32768.f; const std::vector<int16_t>& right=s.r.empty()?s.l:s.r; float sr_=(right[idx]+(right[next]-right[idx])*frac)/32768.f;
      if(filt){ float in[2]={sl,sr_},out[2]; for(int c=0;c<2;c++){ float v3=in[c]-q.ic2[c], v1=a1*q.ic1[c]+a2*v3, v2=q.ic2[c]+a2*q.ic1[c]+a3*v3; q.ic1[c]=2*v1-q.ic1[c]; q.ic2[c]=2*v2-q.ic2[c]; out[c]=v2; } sl=out[0]; sr_=out[1]; }
      float amp=q.velocity*q.env; l+=sl*amp*gl[p]; r+=sr_*amp*gr[p]; float pitchRatio; if(synthMode) pitchRatio=(float)std::exp2(((float)(q.note-s.rootKey)+(P.coarse-.5f)*48.f+(P.fine-.5f)*100.f/100.f)/12.0); else pitchRatio=(float)std::exp2(((P.coarse-.5f)*48.f+(P.fine-.5f))/12.0); q.pos+=(s.rate/sr)*pitchRatio; }
    o[0][i]=std::tanh(l*master);o[1][i]=std::tanh(r*master);
  }
  if(midiAt>0){ for(int i=midiAt;i<midiQueueCount;i++)midiQueue[i-midiAt]=midiQueue[i]; midiQueueCount-=midiAt; }
  for(int i=0;i<midiQueueCount;i++)midiQueue[i].frame=std::max(0,midiQueue[i].frame-n);
}
static VstIntPtr dispatch(AEffect*e,VstInt32 op,VstInt32 idx,VstIntPtr value,void*ptr,float opt){switch(op){
  case effOpen:midiQueueCount=0;loadPads();return 1;
  case effClose:samples.clear();patchPaths.clear();midiQueueCount=0;for(int i=0;i<64;i++)voices[i].active=false;return 1;
  case effSetSampleRate:if(opt>1000)sr=opt;return 1;
  case effSetProgram: selectProgram((int)value); return 1; case effGetProgram:return currentProgram; case effSetProgramName:return 1;
  case effGetChunk: if(ptr){saveStateChunk(); *(void**)ptr=&stateChunk; return (VstIntPtr)sizeof(stateChunk);} return 0;
  case effSetChunk: return restoreStateChunk(ptr, value)?1:0;
  case effGetProgramName:if(ptr){std::string name="MV Library"; if(!patchPaths.empty()&&currentProgram<(int)patchPaths.size()){name=patchPaths[currentProgram].substr(patchPaths[currentProgram].find_last_of("/\\")+1); size_t dot=name.find_last_of('.'); if(dot!=std::string::npos)name.resize(dot);} std::strncpy((char*)ptr,name.c_str(),23); ((char*)ptr)[23]=0;}return 1;
  case 29: if(ptr&&idx>=0&&idx<(VstInt32)patchPaths.size()){std::string name=patchPaths[idx].substr(patchPaths[idx].find_last_of("/\\")+1); size_t dot=name.find_last_of('.'); if(dot!=std::string::npos)name.resize(dot); std::strncpy((char*)ptr,name.c_str(),23); ((char*)ptr)[23]=0; return 1;} return 0; // effGetProgramNameIndexed
  case 6: if(ptr){char*c=(char*)ptr; c[0]=0; if(idx==P_MASTER||idx==P_LEVEL||idx>=P_PADVOL0)std::strcpy(c,"dB");} return 1;   // effGetParamLabel
  case 7: if(ptr&&idx>=0&&idx<NPARAMS)paramDisplay(idx,(char*)ptr); return 1;                                             // effGetParamDisplay
  case 8: if(ptr&&idx>=0&&idx<NPARAMS)paramName(idx,(char*)ptr); return 1;                                                // effGetParamName
  case 26: return (idx>=0&&idx<NPARAMS)?1:0;                                                                              // effCanBeAutomated
  case effProcessEvents:{
    Events*es=(Events*)ptr;if(!es)return 0;
    for(int i=0;i<es->numEvents;i++){
      MidiEvent*m=es->events[i];if(!m||m->type!=1)continue;
      unsigned char*d=(unsigned char*)m->data;unsigned char st=d[0]&0xF0,key=d[1]&127,vel=d[2]&127;
      bool on=(st==0x90&&vel>0),off=(st==0x80)||(st==0x90&&vel==0); if(!on&&!off)continue;
      if(midiQueueCount>=512)continue;
      QueuedMidi q; q.frame=std::max(0,m->deltaFrames);q.note=key;q.velocity=vel;q.on=on;
      int at=midiQueueCount; while(at>0&&midiQueue[at-1].frame>q.frame){midiQueue[at]=midiQueue[at-1];--at;} midiQueue[at]=q; ++midiQueueCount;
    }
    return 1;
  }
  case effGetEffectName:if(ptr)std::strncpy((char*)ptr,"MV-8000",63);return 1;
  case effGetProductString:if(ptr)std::strncpy((char*)ptr,"MV-8000",63);return 1;
  case effGetVendorString:if(ptr)std::strncpy((char*)ptr,"mvlib",63);return 1;
  case effGetVendorVersion:return 100; case effGetVstVersion:return 2400;
  case effCanDo:if(ptr){const char*s=(const char*)ptr;return (!std::strcmp(s,"receiveVstEvents")||!std::strcmp(s,"receiveVstMidiEvent"))?1:0;}return 0;
  default:(void)e;return 0;}}
EXPORT AEffect* VSTPluginMain(AudioMasterCallback cb){if(!cb)return nullptr;std::memset(&fx,0,sizeof(fx));fx.magic=0x56737450;fx.dispatcher=dispatch;fx.setParameter=setP;fx.getParameter=getP;fx.numPrograms=128;fx.numParams=NPARAMS;fx.numInputs=0;fx.numOutputs=2;fx.flags=(1<<4)|(1<<5)|(1<<8);fx.uniqueID=0x524D5632;fx.version=100;fx.processReplacing=process;return &fx;}
EXPORT AEffect* main_plugin(AudioMasterCallback cb){return VSTPluginMain(cb);}
