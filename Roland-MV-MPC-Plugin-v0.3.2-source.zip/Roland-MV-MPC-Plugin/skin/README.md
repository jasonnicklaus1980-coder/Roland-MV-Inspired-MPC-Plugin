# Roland MV-8000-inspired skin reference

`roland_mv8000_reference.png` is the approved visual target for the plugin. `layout.json` records the panel geometry, palette, page regions, and interaction requirements for implementation.

**Important limitation:** these files are design assets, not a native MPC SynthContent skin package. The uploaded JV-880 reference contains install scripts and a plugin registration example but does not include its referenced `payload/Synths/sd88me - VST - JV-880/` skin directory. Therefore, the exact native skin resource format and Q-Link bindings still need to be recovered from a complete working skin or documented SDK before this image can be turned into a real MPC plugin interface.

## What the JV-880 SHA256SUMS revealed (file layout only; contents not seen)
The checksum list for the JV-880 package (`JV-880-1_0.0`) shows the layout of a working MPC plugin skin:
```
payload/vst/jv880.so
payload/Synths/sd88me - VST - JV-880/version.xml
payload/Synths/sd88me - VST - JV-880/Plugin Skins/
    TUI.json, Q-Links.json, "Q-Links - 8by1.json" (identical to Q-Links.json by hash)
    sh_bg_0..5.png                      six backgrounds (pages)
    sh_knob_r18/r20/r24/r26/r27/r30/r32.png   knob sprites by radius
    sh_slider_v_34x99.png, sh_tile_257x37_{on,off}.png, sh_tile_294x30_{on,off}.png
    sh_pill_{on,off}.png, sh_btn_*_{on,off}.png, sh_arrow_*.png
    sh_seg_<param>_<n>_{on,off}.png     segmented selectors, e.g. nvram_tone_0_lfo1form_3_on
    sh_pop_*/sh_popopt_*                popup + popup option images
```
Image names embed parameter identifiers (`nvram_patchCommon_reverbtype`, `nvram_tone_0_wavegroup`), so skins appear to bind by parameter name. **Still unknown:** the JSON schema (TUI.json, Q-Links.json), version.xml, screen size, and the install path. Do not generate a skin until those files are available.
