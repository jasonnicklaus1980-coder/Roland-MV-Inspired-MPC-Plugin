#!/usr/bin/env python3
"""Skin consistency tests. Optional: MV_JV_TUI=/path/to/JV-880/TUI.json also checks our JSON has the same key structure."""
import json, os, re, sys
from pathlib import Path
from PIL import Image
D = Path(__file__).resolve().parents[1] / 'payload/Synths/mvlib - VST - MV-8000/Plugin Skins'
NPARAMS = 30
tui = json.loads((D / 'TUI.json').read_text()); ql = json.loads((D / 'Q-Links.json').read_text())
assert (D / 'Q-Links - 8by1.json').read_bytes() == (D / 'Q-Links.json').read_bytes()
pd = tui['pageData']; defs = {d['key']: d['value'] for d in pd['componentDefinitions']['localComponentDefinitions']}
# every tab root exists, canvas size, unique fn keys
fk = set()
for t in pd['tabs']:
    assert t['componentName'] in defs, t['componentName']; assert t['initialSize'] == '0 0 1280 628'; fk.add(t['fnKeyIndex'])
assert len(fk) == len(pd['tabs'])
# every instance references a defined component, binds to a valid parameter index, stays on canvas, images exist
bound = {}
def png(n): assert (D / n).exists(), n; return Image.open(D / n)
for t in pd['tabs']:
    used = set()
    for c in defs[t['componentName']]['componentsData']:
        cd = c['componentData']; typ = cd['type']; x, y, w, h = map(int, c['bounds']['bounds'].split())
        assert x >= 0 and y >= 0 and x + w <= 1280 and y + h <= 628, (cd['name'], c['bounds']['bounds'])
        if typ == 'Image': png(cd['data']['image']); continue
        assert typ in defs, typ
        m = c['handle remapping']['map']; assert len(m) == 1 and m[0]['key'] == 'Data'
        idx = int(re.fullmatch(r'Parameter (\d+)', m[0]['value']).group(1)); assert 0 <= idx < NPARAMS, idx
        assert idx not in used, ('duplicate binding', t['tabName'], idx); used.add(idx)
        bound.setdefault(t['tabName'], set()).add(idx)
# component definitions: referenced film strips / button images exist with expected geometry
for k, d in defs.items():
    for c in d['componentsData']:
        data = c['componentData']['data']
        if data.get('knobType') == 'FilmStrip':
            im = png(data['filmStrip']); fw, fh = map(int, c['bounds']['bounds'].split()[2:]); assert im.size == (fw, fh * data['numFrames']), (k, im.size, fw, fh)
        if 'onImage' in data: png(data['onImage']); png(data['offImage'])
# Q-Links: indices valid; every Q-Link target is actually on its tab; tabs match TUI
sm = ql['Screen Mode Q-Links']['map']; assert len(sm) == len(pd['tabs'])
for e, t in zip(sm, pd['tabs']):
    assert len(e['Q-Links']) == 16
    for name, idx in e['Q-Links'].items():
        assert idx == -1 or idx in bound[t['tabName']], (t['tabName'], name, idx)
assert len(ql['Program Mode Q-Links']) == 16
import xml.etree.ElementTree as ET
vx = ET.parse(D.parent / 'version.xml').getroot(); assert vx.tag == 'plugincontent' and vx.get('version') == '1.0'
assert vx.findtext('identifier') == 'mvlib.vst.mv-8000' and re.fullmatch(r'\d+(\.\d+){3}', vx.findtext('version'))
assert D.parent.name == 'mvlib - VST - MV-8000'   # folder pattern '<vendor> - VST - <name>' (from JV-880); must match plugin.xml
px = ET.parse(D.parents[3] / 'plugin.xml').getroot(); assert px.get('manufacturer') == 'mvlib' and px.get('name') == 'MV-8000'
print('PASS skin structure:', len(pd['tabs']), 'tabs,', sum(len(v) for v in bound.values()), 'bound controls, Q-Links consistent')
# optional structural comparison with the JV-880 reference
ref = os.environ.get('MV_JV_TUI')
if ref and os.path.exists(ref):
    r = json.load(open(ref))['pageData']; rd = {d['key']: d['value'] for d in r['componentDefinitions']['localComponentDefinitions']}
    def shape(o):
        if isinstance(o, dict): return {k: shape(v) for k, v in o.items() if k not in ('map',)}
        if isinstance(o, list): return [shape(o[0])] if o else []
        return type(o).__name__
    def cmp(a, b, path=''):
        if isinstance(a, dict) and isinstance(b, dict):
            assert a.keys() == b.keys(), (path, sorted(set(a) ^ set(b)))
            for k in a: cmp(a[k], b[k], path + '/' + k)
        elif isinstance(a, list) and isinstance(b, list):
            if a and b: cmp(a[0], b[0], path + '[]')
        else: assert a == b or (a in ('int', 'float') and b in ('int', 'float')), (path, a, b)
    cmp(shape(defs['mvKnob']), shape(rd['shKnob24']), 'mvKnob~shKnob24'); cmp(shape(defs['mvToggle']), shape(rd['shToggle']), 'mvToggle~shToggle')
    cmp(shape(defs['mvSlider']), shape(rd['shSlider_v_34x99']), 'mvSlider~shSlider'); cmp(shape(pd['tabs'][0]), shape(r['tabs'][0]), 'tab')
    cmp(shape(defs['PAD|Pad']), shape(rd['TONE 1|Tone 1']), 'tabroot')
    cmp(shape(ql), shape(json.load(open(os.environ.get('MV_JV_QL', ref.replace('TUI.json', 'Q-Links.json'))))), 'qlinks') if os.path.exists(os.environ.get('MV_JV_QL', ref.replace('TUI.json', 'Q-Links.json'))) else None
    print('PASS structure matches JV-880 reference JSON shapes')
