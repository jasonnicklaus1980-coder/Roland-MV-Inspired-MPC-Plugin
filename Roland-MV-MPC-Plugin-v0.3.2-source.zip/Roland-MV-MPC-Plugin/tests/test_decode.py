#!/usr/bin/env python3
"""Decoder tests: synthetic fixture always; real kit if MV_REAL_KIT env var points at it."""
import os, sys, wave, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import mvff_decode as M

def check(path, expect=None):
    info = M.parse(Path(path).read_bytes())
    assert info['size_matches'], 'header length != file size'
    assert info['fmt'] == {'channels_field': 1, 'bits': 16}
    for r in info['records']:
        frames = r['payload_bytes'] // (4 if r['stereo'] else 2)
        assert 0 < r['end_index'] <= frames, (r['name'], r['end_index'], frames)
    if expect: assert [(r['name'], r['stereo']) for r in info['records']] == expect
    with tempfile.TemporaryDirectory() as t:
        recs = M.decode(Path(path), Path(t))
        for r in recs:
            with wave.open(str(Path(t) / r['output'])) as w:
                assert w.getnchannels() == r['channels'] and w.getnframes() == r['frames']
    return len(info['records'])

n = check('build/fixture.MV0', [('Tone St', True), ('Tone Mono', False)]); print('PASS synthetic fixture:', n, 'records')
real = os.environ.get('MV_REAL_KIT')
if real and os.path.exists(real):
    n = check(real); print('PASS real kit:', n, 'records')
fp = os.environ.get('MV_FACTORY_ZIP')
if fp and os.path.exists(fp):
    import zipfile
    z = zipfile.ZipFile(fp); ok = bad = samples = 0
    for i in z.infolist():
        if not i.filename.upper().endswith('.MV0'): continue
        try: blob = z.read(i)
        except Exception: bad += 1; continue
        info = M.parse(blob); ok += 1; samples += len(info['records'])
        for r in info['records']:
            assert 0 < r['end_index'] <= r['payload_bytes'] // (4 if r['stereo'] else 2)
    print(f'PASS factory patches: {ok} parsed, {samples} samples, {bad} unreadable entries skipped (corrupt zip)')
