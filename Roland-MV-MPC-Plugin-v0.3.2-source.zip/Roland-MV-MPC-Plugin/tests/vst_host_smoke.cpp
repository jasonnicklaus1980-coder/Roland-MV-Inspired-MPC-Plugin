#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <vector>
#include <cmath>
using VstInt32=int32_t; using VstIntPtr=intptr_t;
struct AEffect;
using AudioMasterCallback=VstIntPtr(*)(AEffect*,VstInt32,VstInt32,VstIntPtr,void*,float);
using DispatcherProc=VstIntPtr(*)(AEffect*,VstInt32,VstInt32,VstIntPtr,void*,float);
using ProcessProc=void(*)(AEffect*,float**,float**,VstInt32);
using SetParameterProc=void(*)(AEffect*,VstInt32,float); using GetParameterProc=float(*)(AEffect*,VstInt32);
struct AEffect { VstInt32 magic; DispatcherProc dispatcher; ProcessProc process; SetParameterProc setParameter; GetParameterProc getParameter; VstInt32 numPrograms,numParams,numInputs,numOutputs,flags; VstIntPtr resvd1,resvd2; VstInt32 initialDelay,realQualities,offQualities; float ioRatio; void*object; void*user; VstInt32 uniqueID,version; ProcessProc processReplacing,processDoubleReplacing; char future[56]; };
struct MidiEvent { VstInt32 type,byteSize,deltaFrames,flags; char data[16]; };
struct Events { VstInt32 numEvents; VstIntPtr reserved; MidiEvent* events[1]; };
static VstIntPtr host(AEffect*,VstInt32 op,VstInt32,VstIntPtr,void*,float){ return op==1?2400:0; }
int main(int argc,char**argv){
 if(argc!=2){std::fprintf(stderr,"usage: %s plugin.so\n",argv[0]);return 2;}
 void*h=dlopen(argv[1],RTLD_NOW); if(!h){std::fprintf(stderr,"dlopen: %s\n",dlerror());return 3;}
 using Entry=AEffect*(*)(AudioMasterCallback); auto entry=(Entry)dlsym(h,"VSTPluginMain"); if(!entry){std::fprintf(stderr,"missing VSTPluginMain\n");return 4;}
 AEffect*fx=entry(host); if(!fx||fx->magic!=0x56737450||!fx->dispatcher||!fx->processReplacing){std::fprintf(stderr,"invalid AEffect\n");return 5;}
 fx->dispatcher(fx,0,0,0,nullptr,0); fx->dispatcher(fx,10,0,0,nullptr,44100.f);
 MidiEvent midi{};midi.type=1;midi.byteSize=sizeof(MidiEvent);midi.data[0]=(char)0x90;midi.data[1]=36;midi.data[2]=127;
 struct { VstInt32 numEvents; VstIntPtr reserved; MidiEvent* events[1]; } ev{1,0,{&midi}};
 fx->dispatcher(fx,25,0,0,&ev,0);
 const int n=4096;std::vector<float> l(n),r(n);float* outs[2]={l.data(),r.data()};fx->processReplacing(fx,nullptr,outs,n);
 double energy=0;for(int i=0;i<n;i++)energy+=std::abs(l[i])+std::abs(r[i]);
 fx->dispatcher(fx,1,0,0,nullptr,0);dlclose(h);
 if(energy<0.01){std::fprintf(stderr,"FAIL: pad 1 produced no meaningful audio (energy %.8f)\n",energy);return 6;}
 std::printf("PASS: VST2 entry, open, MIDI note 36, stereo process; output energy %.4f\n",energy);return 0;
}
