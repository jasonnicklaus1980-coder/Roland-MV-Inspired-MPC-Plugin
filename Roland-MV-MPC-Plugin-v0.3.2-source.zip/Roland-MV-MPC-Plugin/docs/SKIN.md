# MPC skin (experimental, generated)

`python3 tools/build_skin.py` writes `payload/Synths/mvlib - VST - MV-8000/Plugin Skins/`: `TUI.json`, `Q-Links.json`, `Q-Links - 8by1.json` (byte-identical copy, as in the JV-880 package) and PNG sprites. `make test-skin` regenerates and validates it.

## Schema (read from the JV-880 `TUI.json` / `Q-Links.json`)
- 1280x628 canvas per tab; `tabs[]` -> `componentName` ("PAD|Pad") -> a local component definition holding `componentsData` (background Image + control instances with absolute `bounds` "x y w h").
- A control instance names a reusable definition (`mvKnob`, `mvSlider`, `mvToggle`) and binds with `"handle remapping": {"Data": "Parameter N"}` where N is the VST2 parameter index.
- Definitions: `Knob` (FilmStrip PNG, 127 frames, vertical drag), `Button` (on/off PNG), `Label` (Name/Value text from the plugin), `Focus` frame; actions `Q-Link`, `Show Overlay` ("knob overlay" from `/usr/share/Akai/Content/Synths/Generic/`), `Toggle Switch`.
- `Q-Links.json`: per-tab `Screen Mode Q-Links` map and a flat `Program Mode Q-Links`.

## This skin
Tab 1 "Pad": Master, Pad (selector), Level, Pan, Coarse, Fine, Gate, Attack, Decay, Sustain, Release, Cutoff, Reson. Q-Links 1-4 = Cutoff, Reson, Attack, Release (also Program Mode). Tab 2 "Mixer": 16 pad-volume sliders, Q-Link n = pad n.
`tests/test_skin.py` checks indices, bounds, image sizes and Q-Link targets; with `MV_JV_TUI` / `MV_JV_QL` pointing at the JV-880 files it also confirms our JSON has identical key structure to the JV-880 definitions (knob, toggle, slider, tab, Q-Links).

## Not verified (needs a device or more files)
1. **Film-strip orientation/frame size.** Sprites are vertical strips (58x7366 knob, 34x12573 slider) because bounds equal one frame. The JV-880 PNGs were not provided to confirm.
2. **`version.xml`**: format now known from the JV-880 file (`<plugincontent version="1.0"><identifier>sd88me.vst.jv-880</identifier><version>1.0.0.0</version>`). Ours is generated as `mvlib.vst.mv-8000` / `0.3.2.0`.
3. **Folder name / install path: now confirmed from the JV-880 package** (`plugin.xml`: name="JV-880", manufacturer="sd88me"; `install.sh`: skin folder `sd88me - VST - JV-880` copied to `/sdcard/Synths/`; plugin in `/sdcard/vst/`; settings `/media/az01-internal/Settings/*/MPC.settings`; `/sdcard/Synths` must be in MPC's SynthContentLocations). Ours: manufacturer `mvlib`, name `MV-8000`, folder `mvlib - VST - MV-8000`. The `plugin.xml` uid is lowercase hex of the VST uniqueID, as in the JV-880 file. Still unconfirmed: that the MPC accepts a skin with a plugin whose vendor/name strings match this way on *our* binary (not run on a device).
4. Font "Titillium Web" and the overlay import paths are assumed present on the MPC (the JV-880 skin uses them).
5. Nothing here has run on an MPC. The ARM plugin binary is still only built by CI.
