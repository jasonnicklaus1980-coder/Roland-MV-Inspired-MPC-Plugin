# Roland MV MPC Plugin — implementation status (0.3.2)

## Verified on the host test harness
- VST2 instrument entry point loads and produces stereo audio.
- `.MV0` patch discovery scans nested category folders. Patch selection loads all sample records from a valid patch and retains the last playable patch if a selected patch is damaged.
- Drum mode maps MIDI notes 36–51 to the first 16 sample records. Synth mode selects the nearest decoded root-key sample, applies chromatic transposition, and uses conservative velocity-name hints (for example MP/FF) where present.
- Samples are stored as signed 16-bit PCM in memory; mono samples use one buffer instead of duplicating data into a second channel.
- MIDI event `deltaFrames` offsets are applied inside the audio block.
- Parameter behavior, VST2 state-chunk save/restore, synthetic MVFF decode, skin JSON/Q-Link structure, installer simulation, and all 16 staged WAVs pass their host-side tests.
- Manually tested a real supplied factory patch (`BPD_Space Ice.MV0`, 18 sample records): drum note 36 and chromatic synth note 60 both produced audio in the x86-64 test host.
- Release assembly now copies `Samples/Patches/` recursively when present, retaining category folders. A staged-patch release packaging check passed.

## Limitations that remain
- The `.MV0` parser decodes sample records, root keys, names, slots, stereo flags, and in-range end trims. The original proprietary partial/key-zone tables, exact velocity zones, loops, patch envelopes, synthesis parameters, effects, and drum-kit pad assignment PRM are not decoded. Synth mode therefore uses nearest-root-key selection, not full MV-8000 patch emulation.
- Sample rate is assumed to be 44.1 kHz; that has not been conclusively decoded from the file format.
- Seven members of the supplied factory ZIP failed CRC/header reads during cataloging; the import utility reports these instead of silently treating them as valid.
- ARMv7 hard-float binary and physical MPC X/Hakai 3.8 playback are not verified in this workspace. Do not install an x86-64 host test `.so` on the MPC.
- Native MPC skin rendering and Q-Link behavior are not verified on the device.
- Full song/project loading and MC-909 support are out of scope for this Drum/Synth build.

## Target build
The included GitHub Actions workflow installs the ARMv7 hard-float cross compiler, builds `payload/vst/roland_mv.so`, checks ELF architecture and exported VST2 symbols, and packages a test artifact. CI compilation does not prove actual MPC compatibility; a device test is still required.
