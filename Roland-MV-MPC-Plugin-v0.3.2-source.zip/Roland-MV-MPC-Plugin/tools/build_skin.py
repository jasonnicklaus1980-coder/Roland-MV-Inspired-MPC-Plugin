#!/usr/bin/env python3
"""Generate the MV MPC plugin skin: TUI.json, Q-Links.json (+ '8by1' copy) and PNG sprites.

Schema learned from the JV-880 MPC plugin skin (TUI.json / Q-Links.json):
  * canvas 1280x628 per tab; controls are component definitions placed with 'bounds' "x y w h"
  * a control binds to a VST2 parameter INDEX via "handle remapping": Data -> "Parameter N"
  * Q-Links.json maps Q-Link 1..16 -> parameter index (-1 = unused), per tab, plus Program Mode
  * knobs/sliders are FilmStrip PNGs (127 frames). ASSUMPTION: frames are stacked vertically.
"""
import json, math, shutil, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'payload/Synths/mvlib - VST - MV-8000/Plugin Skins'
FRAMES = 127
# VST2 parameter indices (see docs/PARAMETERS.md / src/roland_mv_vst2.cpp)
MASTER, PAD, LEVEL, PAN, COARSE, FINE, ATTACK, DECAY, SUSTAIN, RELEASE, GATE, CUTOFF, RESON, PADVOL0 = range(14)
NPARAMS = 30

# ---------- JSON building blocks (shapes copied from the JV-880 skin) ----------
def action(on, handler, handle='', extra=''):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": handle, "additionalData": extra,
            "handle remapping": {"version": 1, "map": []}}
KNOB_ACTIONS = [action('Mouse Down', 'Q-Link', 'Data'), action('Double Click', 'Show Overlay', '', 'knob overlay'),
                action('Enter Pressed', 'Show Overlay', '', 'knob overlay')]
TOGGLE_ACTIONS = [action('Mouse Down', 'Q-Link', 'Data'), action('Enter Pressed', 'Toggle Switch', 'Data')]
def bounds(b, hw='No', inv='Show', vis='Always'):
    return {"version": 2, "acceptsHWFocus": hw, "showWhenDataModelInvalid": inv, "whenVisible": vis,
            "boundsType": "Absolute", "bounds": b, "additionalInvalidatingHandles": []}
def item(name, typ, data, b, remap=None, **kw):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": typ, "data": data},
            "handle remapping": {"version": 1, "map": remap or []}, "bounds": bounds(b, **kw)}
def focus(b):
    return item('Focus', 'Focus', {"version": 1, "backgroundColour": "00000000", "outlineColour": "ff238cff",
                "backgroundInset": 2.0, "outlineThickness": 2.0}, b, vis='WhenFocussed')
def label(name, kind, b, height, colour, case='Original'):
    return item(name, 'Label', {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": "Titillium Web",
                "style": "SemiBold", "height": height}, "colour": colour, "justification": "horizontallyCentred verticallyCentred",
                "case": case}, "type": kind, "handleName": "Data"}, b)
def filmstrip(png, b):
    return item('Knob', 'Knob', {"version": 5, "knobType": "FilmStrip", "filmStrip": png, "numFrames": FRAMES, "invert": False,
                "dragOrientation": "Vertical", "handleName": "Data"}, b)
def button(on, off, b):
    return item('Button', 'Button', {"version": 2, "onImage": on, "offImage": off, "buttonId": 1, "numButtonsInGroup": 1,
                "handleName": "Data", "gestureBehaviour": "Instant"}, b)
def bg_image(png):
    return item('Background', 'Image', {"version": 2, "imageType": "Regular", "colour": "0", "image": png}, '0 0 1280 628')
def definition(key, actions, comps, colour='0'):
    bgd = {"version": 1, "colour": colour, "image": ""}
    return {"key": key, "value": {"version": 4, "actions": actions,
            "backgroundData": {"version": 1, "focussed": dict(bgd), "unfocussed": dict(bgd)}, "ignoreMousePresses": False,
            "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True, "componentsData": comps}}
NAME_C, VAL_C = 'ffd8d6ce', 'ff8a8880'

KNOB_W, KNOB_H = 130, 109
SLIDER_W = 64
def inst(name, typ, idx, x, y, w, h):
    return item(name, typ, {"version": 1, "handleName": "Data"}, f'{x} {y} {w} {h}',
                remap=[{"key": "Data", "value": f"Parameter {idx}"}], hw='Yes', inv='Hide')

def build_json():
    defs = [
        definition('mvKnob', KNOB_ACTIONS, [focus(f'0 0 {KNOB_W} {KNOB_H}'), filmstrip('mv_knob.png', '36 0 58 58'),
            label('Name', 'Name', '0 55 130 20', 17.0, NAME_C), label('Value', 'Value', '0 77 130 26', 22.0, VAL_C, 'Upper Case')]),
        definition('mvSlider', KNOB_ACTIONS, [focus(f'0 0 {SLIDER_W} 155'), filmstrip('mv_slider.png', '15 0 34 99'),
            label('Name', 'Name', f'0 101 {SLIDER_W} 20', 15.0, NAME_C), label('Value', 'Value', f'0 123 {SLIDER_W} 26', 17.0, VAL_C)]),
        definition('mvToggle', TOGGLE_ACTIONS, [focus('0 0 120 58'), button('mv_pill_on.png', 'mv_pill_off.png', '33 4 53 29'),
            label('Name', 'Name', '0 34 120 20', 15.0, NAME_C)]),
    ]
    # --- Pad tab
    comps = [bg_image('mv_bg_0.png')]
    row1 = [('MASTER', MASTER), ('PAD', PAD), ('LEVEL', LEVEL), ('PAN', PAN), ('COARSE', COARSE), ('FINE', FINE)]
    row2 = [('ATTACK', ATTACK), ('DECAY', DECAY), ('SUSTAIN', SUSTAIN), ('RELEASE', RELEASE), ('CUTOFF', CUTOFF), ('RESON', RESON)]
    for r, (y, row) in enumerate(((110, row1), (330, row2))):
        for c, (nm, idx) in enumerate(row):
            comps.append(inst(nm, 'mvKnob', idx, 120 + c * 130, y, KNOB_W, KNOB_H))
    comps.append(inst('GATE', 'mvToggle', GATE, 950, 140, 120, 58))
    comps.append(inst('MODE', 'mvToggle', 29, 1080, 140, 120, 58))
    defs.append(definition('PAD|Pad', [], comps, 'ff17171a'))
    # --- Mixer tab
    comps = [bg_image('mv_bg_1.png')]
    for i in range(16):
        comps.append(inst(f'PAD {i+1}', 'mvSlider', PADVOL0 + i, 85 + i * 70, 200, SLIDER_W, 155))
    defs.append(definition('MIXER|Mixer', [], comps, 'ff17171a'))
    tabs = [{"version": 3, "tabName": n, "fnKeyIndex": i, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
             "componentName": f"{n.upper()}|{n}", "initialSize": "0 0 1280 628", "scale": 1.0} for i, n in enumerate(['Pad', 'Mixer'])]
    tui = {"pageData": {"version": 1, "componentDefinitions": {"version": 2, "importFiles": [
        "/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json", "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
        "localComponentDefinitions": defs}, "info": {"version": 1, "type": "CompleteDescription"}, "tabs": tabs}}
    # --- Q-Links
    pad_q = [CUTOFF, RESON, ATTACK, RELEASE, LEVEL, PAN, COARSE, FINE, DECAY, SUSTAIN, PAD, GATE, MASTER, 29, -1, -1]
    mix_q = [PADVOL0 + i for i in range(16)]
    ql = lambda v: {f"Q-Link {i+1}": x for i, x in enumerate(v)}
    qjson = {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
             "Screen Mode Q-Links": {"version": 4, "map": [
                 {"Tab": 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": ql(pad_q)},
                 {"Tab": 2, "SubTab": 1, "Bank Direction": "Column", "Q-Links": ql(mix_q)}]},
             "Program Mode Q-Links": ql(pad_q)}
    return tui, qjson

# ---------- PNG sprites ----------
SS = 4
def font(sz, bold=True):
    return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans%s.ttf' % ('-Bold' if bold else ''), sz)
def knob_strip(path):
    W = H = 58; strip = Image.new('RGBA', (W, H * FRAMES), (0, 0, 0, 0))
    for f in range(FRAMES):
        v = f / (FRAMES - 1); im = Image.new('RGBA', (W * SS, H * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = W * SS / 2
        def arc(r, a0, a1, col, w):
            d.arc([c - r, c - r, c + r, c + r], a0 - 90, a1 - 90, fill=col, width=w)
        arc(26 * SS, -135, 135, (58, 64, 70, 255), 4 * SS)
        if v > 0: arc(26 * SS, -135, -135 + 270 * v, (35, 140, 255, 255), 4 * SS)
        r = 20 * SS; d.ellipse([c - r, c - r, c + r, c + r], fill=(28, 33, 38, 255), outline=(90, 98, 106, 255), width=SS)
        r2 = 15 * SS; d.ellipse([c - r2, c - r2, c + r2, c + r2], fill=(44, 51, 58, 255))
        a = math.radians(-135 + 270 * v)
        d.line([c + 5 * SS * math.sin(a), c - 5 * SS * math.cos(a), c + 17 * SS * math.sin(a), c - 17 * SS * math.cos(a)], fill=(241, 245, 248, 255), width=3 * SS)
        strip.paste(im.resize((W, H), Image.LANCZOS), (0, f * H))
    strip.save(path)
def slider_strip(path):
    W, H = 34, 99; strip = Image.new('RGBA', (W, H * FRAMES), (0, 0, 0, 0))
    for f in range(FRAMES):
        v = f / (FRAMES - 1); im = Image.new('RGBA', (W * SS, H * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        top, bot = 12 * SS, 87 * SS; y = bot - (bot - top) * v; cx = W * SS / 2
        d.rounded_rectangle([cx - 2 * SS, top - 4 * SS, cx + 2 * SS, bot + 4 * SS], 2 * SS, fill=(8, 10, 12, 255), outline=(70, 78, 86, 255))
        if v > 0: d.rounded_rectangle([cx - 2 * SS, y, cx + 2 * SS, bot + 4 * SS], 2 * SS, fill=(35, 140, 255, 255))
        d.rounded_rectangle([cx - 13 * SS, y - 8 * SS, cx + 13 * SS, y + 8 * SS], 3 * SS, fill=(190, 196, 200, 255), outline=(0, 0, 0, 255), width=SS)
        d.line([cx - 10 * SS, y, cx + 10 * SS, y], fill=(30, 30, 30, 255), width=2 * SS)
        strip.paste(im.resize((W, H), Image.LANCZOS), (0, f * H))
    strip.save(path)
def pill(path, on):
    im = Image.new('RGBA', (53 * SS, 29 * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([SS, SS, 52 * SS, 28 * SS], 13 * SS, fill=(35, 140, 255, 255) if on else (40, 46, 52, 255), outline=(8, 10, 12, 255), width=2 * SS)
    kx = 39 * SS if on else 14 * SS; d.ellipse([kx - 9 * SS, 5 * SS, kx + 9 * SS, 23 * SS], fill=(241, 245, 248, 255) if on else (130, 138, 146, 255))
    im.resize((53, 29), Image.LANCZOS).save(path)
def panel(d, box, title, tx=None):
    d.rounded_rectangle(box, 10, fill=(24, 30, 36), outline=(58, 66, 74), width=2)
    d.text(((tx or box[0] + 20), box[1] + 10), title, font=font(17), fill=(35, 140, 255))
def backgrounds(out):
    im = Image.new('RGB', (1280, 628), (23, 23, 26)); d = ImageDraw.Draw(im)
    d.text((40, 20), 'MV-8000', font=font(30), fill=(241, 245, 248)); d.text((190, 29), 'Pad parameters  -  edits the pad chosen with PAD', font=font(16, False), fill=(138, 136, 128))
    panel(d, (100, 70, 1100, 262), 'SAMPLE / PAD', 120); panel(d, (100, 296, 1100, 488), 'ENVELOPE', 120)
    d.text((640, 306), 'FILTER', font=font(17), fill=(35, 140, 255)); d.line([(630, 316), (630, 480)], fill=(58, 66, 74), width=2)
    d.text((100, 520), 'Q-Links 1-4: Cutoff, Reson, Attack, Release    5-8: Level, Pan, Coarse, Fine    9-12: Decay, Sustain, Pad, Gate    13: Master', font=font(14, False), fill=(138, 136, 128))
    im.save(out / 'mv_bg_0.png')
    im = Image.new('RGB', (1280, 628), (23, 23, 26)); d = ImageDraw.Draw(im)
    d.text((40, 20), 'MV-8000', font=font(30), fill=(241, 245, 248)); d.text((190, 29), 'Pad volume  -  Q-Links 1-16 control pads 1-16', font=font(16, False), fill=(138, 136, 128))
    panel(d, (60, 130, 1220, 400), 'PAD VOLUME', 80); im.save(out / 'mv_bg_1.png')

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    tui, q = build_json()
    (OUT / 'TUI.json').write_text(json.dumps(tui, indent=4), encoding='utf-8')
    (OUT / 'Q-Links.json').write_text(json.dumps(q, indent=4), encoding='utf-8')
    shutil.copyfile(OUT / 'Q-Links.json', OUT / 'Q-Links - 8by1.json')
    knob_strip(OUT / 'mv_knob.png'); slider_strip(OUT / 'mv_slider.png'); pill(OUT / 'mv_pill_on.png', True); pill(OUT / 'mv_pill_off.png', False)
    backgrounds(OUT)
    if OUT.name == 'Plugin Skins':   # version.xml sits next to 'Plugin Skins' (format from the JV-880 package)
        (OUT.parent / 'version.xml').write_text("<?xml version='1.0' encoding='utf-8'?>\n<plugincontent version=\"1.0\">\n\t<identifier>mvlib.vst.mv-8000</identifier>\n\t<version>0.3.2.0</version>\n</plugincontent>\n", encoding='utf-8')
    print('wrote', OUT)
if __name__ == '__main__':
    main()
