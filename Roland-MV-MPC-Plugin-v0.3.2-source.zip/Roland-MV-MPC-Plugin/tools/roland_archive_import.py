#!/usr/bin/env python3
"""Prepare Roland archives for the Roland MV MPC test instrument.

Supports: ZIP archives containing WAV/AIFF audio; MVFF .MV0 files matching the
observed PRM(0x26)/WAVE layout (experimental audio interpretation).
Preserves all original files. Does not claim to decode proprietary .SVD/.MCS.
"""
import argparse, json, shutil, subprocess, sys, zipfile
from pathlib import Path

AUDIO={'.wav','.wave','.aif','.aiff'}
ROLAND={'.mv0','.svd','.mcs','.img','.svq','.mid','.smf'}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source',type=Path,help='source ZIP, directory, or Roland file')
    ap.add_argument('output',type=Path,help='output folder for MPC-ready samples and originals')
    ap.add_argument('--sample-rate',type=int,default=44100,help='assumed rate for experimental MVFF extraction')
    a=ap.parse_args(); out=a.output.resolve(); originals=out/'Originals'; samples=out/'Samples'
    originals.mkdir(parents=True,exist_ok=True); samples.mkdir(parents=True,exist_ok=True)
    report={'source':str(a.source),'sample_rate_assumption_for_mvff':a.sample_rate,'audio_copied':[],'mvff_extractions':[],'unparsed_roland_files':[],'notes':[]}
    staging=out/'_staging'; staging.mkdir(exist_ok=True)
    files=[]
    if a.source.is_dir():
        for f in a.source.rglob('*'):
            if f.is_file():
                dest=staging/f.relative_to(a.source); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,dest); files.append(dest)
    elif zipfile.is_zipfile(a.source):
        with zipfile.ZipFile(a.source) as z:
            for info in z.infolist():
                if info.is_dir(): continue
                # block path traversal from untrusted archives
                rel=Path(info.filename)
                if rel.is_absolute() or '..' in rel.parts: continue
                dest=staging/rel; dest.parent.mkdir(parents=True,exist_ok=True)
                with z.open(info) as src, dest.open('wb') as dst: shutil.copyfileobj(src,dst)
                files.append(dest)
    elif a.source.is_file():
        dest=staging/a.source.name; shutil.copy2(a.source,dest); files=[dest]
    else: ap.error('Source path does not exist')
    # Keep complete source hierarchy in output for files not understood by converter.
    for f in files:
        ext=f.suffix.lower()
        if ext in AUDIO:
            target=originals/f.relative_to(staging); target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,target)
            # Put first 16 audio files into numbered pads, keeping originals separately.
            if len(report['audio_copied'])<16:
                idx=len(report['audio_copied'])+1
                if ext in {'.wav','.wave'}:
                    pad=samples/f'pad{idx:02d}.wav'; shutil.copy2(f,pad)
                    report['audio_copied'].append({'source':str(f.relative_to(staging)),'pad':pad.name,'method':'copied WAV; original preserved'})
                else:
                    report['notes'].append(f'AIFF found but not converted to WAV automatically: {f.relative_to(staging)}')
                    report['audio_copied'].append({'source':str(f.relative_to(staging)),'pad':None,'method':'AIFF preserved; needs conversion'})
            continue
        if ext=='.mv0':
            dest=originals/f.relative_to(staging); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,dest)
            try:
                from mvff_decode import decode
                target=samples/('mvff_'+f.stem); records=decode(f,target,a.sample_rate)
                # Also stage up to 16 extracted candidates at the plugin's expected pad paths.
                staged=[]
                for rec in records:
                    if len(staged)>=16: break
                    srcwav=target/rec['output']; pad=samples/f"pad{len(staged)+1:02d}.wav"
                    shutil.copy2(srcwav,pad); staged.append(pad.name)
                report['mvff_extractions'].append({'source':str(f.relative_to(staging)),'output':str(target.relative_to(out)),'plugin_pad_wavs':staged,'status':'experimental candidate extraction; encoding/rate unverified'})
            except Exception as e:
                report['unparsed_roland_files'].append({'file':str(f.relative_to(staging)),'extension':ext,'reason':str(e)})
            continue
        if ext in ROLAND:
            dest=originals/f.relative_to(staging); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,dest)
            report['unparsed_roland_files'].append({'file':str(f.relative_to(staging)),'extension':ext,'reason':'preserved byte-for-byte; native decoder not implemented, no format assumptions made'})
    shutil.rmtree(staging,ignore_errors=True)
    if not report['audio_copied'] and not report['mvff_extractions']:
        report['notes'].append('No WAV audio or recognized experimental MVFF records were converted. This archive may contain patch/sequence metadata rather than standalone PCM samples.')
    report['notes'] += ['This tool prepares sample assets for the test plugin; it does not make the MPC plugin parse SVD/MCS/IMG/SVQ natively.','For MC-909 SVD/MCS, the files are preserved without modification until their binary format is identified and validated.','The current plugin expects Samples/pad01.wav through pad16.wav in its configured MPC path.']
    (out/'import-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (out/'README-IMPORT.txt').write_text('ROLAND MPC TEST IMPORT\n\n1. Review import-report.json.\n2. Copy Samples/pad01.wav ... pad16.wav to /sdcard/Synths/mvlib - VST - MV-8000/Samples/ on the MPC only if valid WAV pads were created.\n3. Original files are preserved in Originals/.\n4. Proprietary .SVD/.MCS are NOT decoded by this tool. Do not rename them to WAV.\n5. MVFF extractions are experimental; audition and verify pitch/noise against original hardware.\n',encoding='utf-8')
    print(json.dumps({'output':str(out),'wav_pads':len([x for x in report['audio_copied'] if x['pad']]),'mvff_files':len(report['mvff_extractions']),'unparsed_roland_files':len(report['unparsed_roland_files']),'report':str(out/'import-report.json')},indent=2))
if __name__=='__main__': main()
