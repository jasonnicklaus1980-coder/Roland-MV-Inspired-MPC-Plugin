#!/usr/bin/env python3
"""Prepare up to 16 PCM WAV files for the prototype's pad sample engine.

Copies (does not modify) supported mono/stereo 16-bit PCM WAV files to pad01.wav
through pad16.wav. The VST prototype currently reads these files from
/sdcard/Synths/mvlib - VST - MV-8000/Samples on MPC OS.
"""
import argparse, os, shutil, struct, sys, wave

def supported(path):
    try:
        with wave.open(path, 'rb') as w:
            return w.getcomptype() == 'NONE' and w.getsampwidth() == 2 and w.getnchannels() in (1, 2) and w.getnframes() > 0
    except (wave.Error, EOFError, OSError):
        return False

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source_dir', help='Folder containing .wav files')
    ap.add_argument('output_dir', help='Destination Samples folder')
    ap.add_argument('--limit',type=int,default=16,choices=range(1,17))
    a=ap.parse_args()
    if not os.path.isdir(a.source_dir): ap.error('source_dir is not a directory')
    files=sorted(os.path.join(a.source_dir,n) for n in os.listdir(a.source_dir) if n.lower().endswith('.wav'))
    good=[p for p in files if supported(p)][:a.limit]
    if not good:
        print('No supported PCM WAV files found (requires 16-bit mono/stereo PCM).',file=sys.stderr);return 2
    os.makedirs(a.output_dir,exist_ok=True)
    for i,p in enumerate(good,1):
        dest=os.path.join(a.output_dir,'pad%02d.wav'%i)
        shutil.copy2(p,dest)
        print('%02d  %s -> %s'%(i,os.path.basename(p),dest))
    print('Prepared %d pad sample(s). Pad notes are MIDI 36–51.'%len(good))
    if len(good)<16: print('Remaining pads will be silent until matching padNN.wav files are provided.')
    return 0
if __name__=='__main__': raise SystemExit(main())
