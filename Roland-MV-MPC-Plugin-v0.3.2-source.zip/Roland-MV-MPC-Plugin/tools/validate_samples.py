#!/usr/bin/env python3
"""Validate staged WAV files without asserting inferred Roland encoding is correct."""
import json, sys, wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SAMPLE_DIR = ROOT / "Samples"
MANIFEST = SAMPLE_DIR / "Dirt-Grime" / "manifest.json"

def main():
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    records = manifest.get("records", [])
    if len(records) != 16:
        raise SystemExit(f"FAIL: expected 16 manifest records, got {len(records)}")
    errors=[]
    for rec in records:
        path=SAMPLE_DIR / rec["output"]
        try:
            with wave.open(str(path), "rb") as w:
                frames=w.getnframes(); channels=w.getnchannels(); width=w.getsampwidth(); rate=w.getframerate()
                data=w.readframes(frames)
            if not frames or not data: errors.append(f"{path.name}: empty audio")
            if channels not in (1,2): errors.append(f"{path.name}: unsupported channel count {channels}")
            if width != 2: errors.append(f"{path.name}: expected 16-bit PCM, got {width*8}-bit")
            if rate <= 0: errors.append(f"{path.name}: invalid sample rate")
            if "channels" in rec and rec["channels"]!=channels: errors.append(f"{path.name}: manifest says {rec['channels']} ch, WAV has {channels}")
            if "frames" in rec and rec["frames"]!=frames: errors.append(f"{path.name}: manifest frames {rec['frames']} != WAV {frames}")
            if len(data) != frames*channels*width: errors.append(f"{path.name}: truncated frame data")
            print(f"{'OK' if not errors else 'CHECK'} {path.name:10s} {rec['source_name'][:18]:18s} {rate} Hz {channels} ch {frames/rate:.2f}s")
        except Exception as exc:
            errors.append(f"{path.name}: {exc}")
    if errors:
        print("\nValidation failures:", *errors, sep="\n- ", file=sys.stderr)
        return 1
    print("\nPASS: all 16 candidate WAV files are structurally readable.")
    print("NOTE: sample rate (44.1 kHz) is assumed; it is not stored in the decoded MVFF fields.")
    return 0
if __name__ == "__main__": raise SystemExit(main())
