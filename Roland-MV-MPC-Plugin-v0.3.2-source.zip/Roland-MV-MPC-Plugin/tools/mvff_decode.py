#!/usr/bin/env python3
"""MVFF (.MV0 / MV-8000 / MV-8800 patch container) sample extractor.

Container layout observed in a real MV-series drum kit (MA_Dirt&GrimeKit.MV0):
  'MVFF' u32be(total-8)  u32be(0x75)  'PAT '
  'FMT ' u32be(12)  [u32 0, u32 channels?(1), u32 bits(16)]
  'PRM ' u32be(len)  kit parameter block (not decoded)
  'SMPL' u32be(len)  u32 0, then repeated: 'PRM '(0x26) + 'WAVE' u32be(bytes) + payload
Per-sample PRM(0x26): u32 2, u32 slot, name[12], 8 zero bytes, u32 end_index,
  u8 0x27 (constant in all 1571 factory samples, meaning unknown), u8 root_key (MIDI),
  u16 flag (0x0100 = stereo in the Dirt&Grime kit; always 0 in the 96 factory patches), u16 0x2EE0 (constant, unknown)
Payload is signed 16-bit big-endian PCM. Samples whose flag is 0x0100 are treated as interleaved
L/R stereo; others as mono. end_index is the sample end point: it equals the last frame for
untrimmed samples but is often smaller (trimmed/loop end), so it is NOT a channel-count indicator.
Sample rate is NOT stored in anything decoded here; 44100 Hz is assumed (a 4.000 s
mono sample of exactly 176400 frames supports it, but it is not proof).
"""
import argparse, json, struct, wave
from pathlib import Path


def parse(blob: bytes):
    if blob[:4] != b'MVFF':
        raise ValueError('Missing MVFF signature')
    declared = struct.unpack_from('>I', blob, 4)[0]
    info = {'declared_len': declared, 'size_matches': declared == len(blob) - 8, 'chunks': []}
    pos = blob.find(b'FMT ')
    if pos < 0:
        raise ValueError('No FMT chunk')
    smpl = None
    while pos + 8 <= len(blob):
        tag = blob[pos:pos + 4]
        n = struct.unpack_from('>I', blob, pos + 4)[0]
        if not all(65 <= c <= 90 or c == 32 for c in tag) or pos + 8 + n > len(blob):
            break
        info['chunks'].append((tag.decode(), pos, n))
        if tag == b'FMT ' and n >= 12:
            _, ch, bits = struct.unpack_from('>3I', blob, pos + 8)
            info['fmt'] = {'channels_field': ch, 'bits': bits}
        if tag == b'PRM ' and 'kit_prm' not in info:
            info['kit_prm'] = (pos + 8, n)
        if tag == b'SMPL':
            smpl = (pos + 8, n)
        pos += 8 + n
    if smpl is None:
        raise ValueError('No SMPL chunk')
    p, end = smpl[0] + 4, smpl[0] + smpl[1]
    recs = []
    while p + 8 <= end and blob[p:p + 4] == b'PRM ':
        plen = struct.unpack_from('>I', blob, p + 4)[0]
        q = p + 8 + plen
        if plen < 0x26 or blob[q:q + 4] != b'WAVE':
            raise ValueError(f'Unexpected record at {p}')
        wlen = struct.unpack_from('>I', blob, q + 4)[0]
        body = blob[p + 8:p + 8 + plen]
        name = body[8:20].split(b'\0', 1)[0].decode('latin-1').strip()
        end_idx = (struct.unpack_from('>H', body, 28)[0] << 16) | struct.unpack_from('>H', body, 30)[0]
        root = body[33]; flag, unk = struct.unpack_from('>2H', body, 34)
        recs.append({'slot': struct.unpack_from('>I', body, 4)[0], 'name': name, 'record_offset': p,
                     'payload_offset': q + 8, 'payload_bytes': wlen, 'end_index': end_idx,
                     'root_key': root, 'stereo': flag == 0x0100, 'flag': flag, 'unk': unk})
        p = q + 8 + wlen
    if not recs:
        raise ValueError('No sample records')
    info['records'] = recs
    return info


def decode(src: Path, out: Path, sample_rate: int = 44100):
    blob = src.read_bytes()
    info = parse(blob)
    out.mkdir(parents=True, exist_ok=True)
    manifest_recs = []
    for i, r in enumerate(info['records']):
        ch = 2 if r['stereo'] else 1
        n = r['payload_bytes'] - (r['payload_bytes'] % (2 * ch))
        raw = bytearray(blob[r['payload_offset']:r['payload_offset'] + n])
        raw[0::2], raw[1::2] = raw[1::2], raw[0::2]  # BE -> LE
        wav_name = f'pad{i + 1:02d}.wav'
        with wave.open(str(out / wav_name), 'wb') as wf:
            wf.setnchannels(ch); wf.setsampwidth(2); wf.setframerate(sample_rate); wf.writeframes(bytes(raw))
        manifest_recs.append({'pad': i + 1, 'source_name': r['name'], 'output': wav_name,
                              'record_offset': r['record_offset'], 'wave_payload_bytes': r['payload_bytes'],
                              'channels': ch, 'frames': n // (2 * ch), 'root_key': r['root_key'],
                              'sample_rate_hz_assumed': sample_rate})
    manifest = {'source_file': src.name, 'signature': 'MVFF', 'size_matches_header': info['size_matches'],
                'decoder_status': 'sample extraction from observed layout; kit parameter block (PRM) not decoded',
                'assumptions': ['signed 16-bit big-endian PCM', 'channel count from per-sample flag 0x0100',
                                f'{sample_rate} Hz (not stored in decoded fields)'],
                'records': manifest_recs}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    return manifest_recs


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('input', type=Path); ap.add_argument('output_dir', type=Path)
    ap.add_argument('--sample-rate', type=int, default=44100)
    a = ap.parse_args()
    recs = decode(a.input, a.output_dir, a.sample_rate)
    print(f'Extracted {len(recs)} samples to {a.output_dir}')
    for r in recs:
        print(f"pad{r['pad']:02d}: {r['source_name']} {'stereo' if r['channels']==2 else 'mono'} {r['frames']} frames -> {r['output']}")
