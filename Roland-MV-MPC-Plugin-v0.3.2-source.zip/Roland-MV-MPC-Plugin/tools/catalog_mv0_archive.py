#!/usr/bin/env python3
"""Build a metadata-only catalog for a Roland MVFF .MV0 patch archive.

This does not extract or redistribute factory audio. Invalid ZIP members and
unrecognized .MV0 variants are reported instead of silently discarded.
"""
import argparse, json, zipfile
from pathlib import Path
from mvff_decode import parse

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source',type=Path,help='ZIP archive or directory containing .MV0 files')
    ap.add_argument('output',type=Path,help='JSON catalog output path')
    a=ap.parse_args(); rows=[]; errors=[]
    def inspect(name, blob):
        try:
            x=parse(blob)
            rows.append({'path':name,'size_bytes':len(blob),'header_length_matches':x['size_matches'],
              'sample_count':len(x['records']),'samples':[{'slot':r['slot'],'name':r['name'],'root_key':r['root_key'],
              'channels':2 if r['stereo'] else 1,'payload_bytes':r['payload_bytes'],'end_index':r['end_index']} for r in x['records']]})
        except Exception as e: errors.append({'path':name,'error':str(e)})
    if a.source.is_dir():
        for f in sorted(a.source.rglob('*')):
            if f.is_file() and f.suffix.lower()=='.mv0': inspect(str(f.relative_to(a.source)),f.read_bytes())
    elif zipfile.is_zipfile(a.source):
        with zipfile.ZipFile(a.source) as z:
            for item in z.infolist():
                if item.is_dir() or not item.filename.lower().endswith('.mv0'): continue
                try: inspect(item.filename,z.read(item))
                except Exception as e: errors.append({'path':item.filename,'error':str(e)})
    else: ap.error('source must be a directory or ZIP archive')
    out={'format':'mvlib-mv0-catalog-v1','source':a.source.name,'patch_files_seen':len(rows)+len(errors),
         'parsed_files':len(rows),'failed_files':len(errors),'total_sample_records':sum(len(r['samples']) for r in rows),
         'limitations':['Metadata only; does not decode patch synthesis parameters, zones, envelopes, effects, or project sequences.',
                        'PCM sample rate is not known from the fields decoded by this experimental parser.'],
         'patches':rows,'errors':errors}
    a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:out[k] for k in ('patch_files_seen','parsed_files','failed_files','total_sample_records')},indent=2))
if __name__=='__main__': main()
