#!/usr/bin/env python3
"""Conservative inspector for Roland MVFF patch containers; not a full decoder."""
import argparse, os, struct, sys

KNOWN = {b'MVFF', b'PAT ', b'FMT ', b'PRM ', b'SMP ', b'WAV ', b'NAME', b'END '}

def inspect(path):
    with open(path, 'rb') as f: data = f.read()
    print(f'File: {os.path.basename(path)}')
    print(f'Size: {len(data)} bytes')
    print(f'Header: {data[:16].hex(" ")}')
    if not data.startswith(b'MVFF'):
        print('Result: no MVFF signature; format not identified.')
        return 2
    print('Signature: MVFF (Roland MV-series container candidate)')
    # The first 4 bytes are the container signature. Subsequent chunks appear
    # as 4-byte ID + big-endian length; this is a heuristic inventory only.
    pos, count = 4, 0
    print('\nConservative chunk scan (candidate headers; not semantic decoding):')
    while pos + 8 <= len(data) and count < 10000:
        tag = data[pos:pos+4]
        size = struct.unpack('>I', data[pos+4:pos+8])[0]
        # accept only printable-ish IDs and sizes fully inside file
        printable = all(32 <= c <= 126 for c in tag)
        if not printable or size > len(data) - (pos + 8):
            # Not a confirmed chunk boundary. Advance by one byte to look for
            # recognizable tags without asserting undocumented structure.
            pos += 1
            continue
        if tag in KNOWN or tag.strip() and sum(32 <= c <= 126 for c in tag) >= 3:
            print(f'  offset=0x{pos:08x} id={tag!r} length={size}')
            count += 1
            # Only jump on plausible chunks; MVFF internals are not fully documented.
            pos += 8 + size
        else:
            pos += 1
    print(f'\nCandidate chunks listed: {count}')
    print('Limit: chunk boundaries/lengths are heuristic; fields and audio are not decoded.')
    print('Next required evidence: multiple known-good MV patches plus their sample assets.')
    return 0

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('file')
    args = ap.parse_args()
    try: sys.exit(inspect(args.file))
    except OSError as e:
        print(f'error: {e}', file=sys.stderr); sys.exit(1)
